const supabase = require('../config/supabaseClient');
const githubService = require('../services/githubService');

exports.getDashboardData = async (req, res) => {
    try {
        const userId = req.user.id;

        // Fetch user data
        const { data: user } = await supabase
            .from('users')
            .select('username, avatar_url')
            .eq('id', userId)
            .single();

        // Fetch contribution metrics
        const { data: contributions } = await supabase
            .from('contributions')
            .select('*')
            .eq('user_id', userId)
            .single();

        // Fetch recent tracked repos
        const { data: repos } = await supabase
            .from('tracked_repos')
            .select('*')
            .eq('user_id', userId)
            .order('created_at', { ascending: false })
            .limit(5);

        // Fetch activity logs
        const { data: activityLogs } = await supabase
            .from('activity_logs')
            .select('*')
            .eq('user_id', userId)
            .order('date', { ascending: false });

        res.json({
            user,
            stats: contributions || { commits: 0, pull_requests: 0, issues: 0 },
            repos: repos || [],
            recentActivity: activityLogs || []
        });

    } catch (err) {
        console.error('Dashboard Error', err);
        res.status(500).send('Server Error');
    }
};

exports.syncData = async (req, res) => {
    try {
        const result = await githubService.syncGitHubData(req.user.id);
        res.json(result);
    } catch (err) {
        console.error('Sync Error', err);
        res.status(500).send('Failed to sync. Make sure you logged in with GitHub.');
    }
};
