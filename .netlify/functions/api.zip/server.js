require('dotenv').config();
const express = require('express');
const cors = require('cors');
// DB is handled directly via Supabase API calls in controllers

const app = express();

// Init Middleware
app.use(express.json());
app.use(cors());

// Define Routes
app.use('/api/auth', require('./routes/authRoutes'));
app.use('/api/repos', require('./routes/repoRoutes'));
app.use('/api/dashboard', require('./routes/dashboardRoutes'));

const PORT = process.env.PORT || 5000;

// Only listen locally, if we are in Netlify it's handled by serverless-http
if (process.env.NODE_ENV !== 'production' && !process.env.NETLIFY) {
  app.listen(PORT, () => console.log(`Server started on port ${PORT}`));
}

module.exports = app;
