const axios = require('axios');
const supabase = require('../config/supabaseClient');

const githubApi = axios.create({
    baseURL: 'https://api.github.com',
    headers: {
        Accept: 'application/vnd.github.v3+json'
    }
});

exports.syncGitHubData = async (userId) => {
    try {
        // 1. Get user access token from DB
        const { data: user, error: userError } = await supabase
            .from('users')
            .select('access_token, username')
            .eq('id', userId)
            .single();

        if (userError || !user || !user.access_token) {
            throw new Error('User not found or missing GitHub access token');
        }

        const accessToken = user.access_token;
        const config = {
            headers: { Authorization: `token ${accessToken}` }
        };

        // 2. Fetch User's Repositories
        const reposResponse = await githubApi.get('/user/repos?type=owner&per_page=10', config);
        const repos = reposResponse.data;

        let totalCommits = 0;
        let totalPRs = 0;
        let totalIssues = 0;
        const logs = [];

        // 3. Reconcile repositories in tracked_repos
        for (const repo of repos) {
            const { data: dbRepo, error: repoError } = await supabase
                .from('tracked_repos')
                .upsert([
                    {
                        user_id: userId,
                        repo_name: repo.name,
                        repo_url: repo.html_url,
                        language: repo.language || 'Unknown'
                    }
                ], { onConflict: 'user_id, repo_name' }) // Assuming unique constraint or logic handles this. But wait, tracked_repos doesn't have unique constraint. Let's just insert if not exists.
                .select()
                .single();
            
            // To be safe, we fetch first:
            let actualRepoId;
            let { data: existingRepo } = await supabase
                .from('tracked_repos')
                .select('id')
                .eq('user_id', userId)
                .eq('repo_name', repo.name)
                .single();

            if (!existingRepo) {
                const { data: newRepo } = await supabase
                    .from('tracked_repos')
                    .insert([{
                        user_id: userId,
                        repo_name: repo.name,
                        repo_url: repo.html_url,
                        language: repo.language || 'Unknown'
                    }])
                    .select()
                    .single();
                actualRepoId = newRepo?.id;
            } else {
                actualRepoId = existingRepo.id;
            }

            if (!actualRepoId) continue;

            // Fetch Commits (very basic approx via events, or specific commit route)
            // Note: /repos/:owner/:repo/commits requires many calls, so we use user events instead
        }

        // 4. Fetch User Events (PushEvent, PullRequestEvent, IssuesEvent)
        const eventsResponse = await githubApi.get(`/users/${user.username}/events/public?per_page=100`, config);
        
        for (const event of eventsResponse.data) {
            if (event.type === 'PushEvent') {
                totalCommits += event.payload.commits.length;
                logs.push({ type: 'Commit', repo_name: event.repo.name, date: event.created_at });
            } else if (event.type === 'PullRequestEvent' && event.payload.action === 'opened') {
                totalPRs++;
                logs.push({ type: 'PR', repo_name: event.repo.name, date: event.created_at });
            } else if (event.type === 'IssuesEvent' && event.payload.action === 'opened') {
                totalIssues++;
                logs.push({ type: 'Issue', repo_name: event.repo.name, date: event.created_at });
            }
        }

        // 5. Update overall contributions
        // For simplicity, we just dump overalls into the first repo or generic stats
        const { error: contribError } = await supabase
            .from('contributions')
            .upsert([
                {
                    user_id: userId,
                    commits: totalCommits,
                    pull_requests: totalPRs,
                    issues: totalIssues
                }
            ], { onConflict: 'user_id' }); // Require an onConflict or just do a manual update

        // The safe way for generic overalls: Let's check first
        const { data: existingContrib } = await supabase
            .from('contributions')
            .select('*')
            .eq('user_id', userId)
            .is('repo_id', null)
            .single();

        if (!existingContrib) {
            await supabase.from('contributions').insert([{
                user_id: userId,
                commits: totalCommits,
                pull_requests: totalPRs,
                issues: totalIssues
            }]);
        } else {
            await supabase.from('contributions').update({
                commits: totalCommits,
                pull_requests: totalPRs,
                issues: totalIssues,
                last_updated: new Date()
            }).eq('id', existingContrib.id);
        }

        // 6. Insert latest activity logs
        if (logs.length > 0) {
            // Delete old logs first to prevent bloat
            await supabase.from('activity_logs').delete().eq('user_id', userId);
            
            const logsToInsert = logs.slice(0, 15).map(log => ({
                user_id: userId,
                type: log.type,
                repo_name: log.repo_name,
                date: log.date
            }));
            await supabase.from('activity_logs').insert(logsToInsert);
        }

        return { message: 'GitHub data synced successfully!', stats: { totalCommits, totalPRs, totalIssues } };

    } catch (err) {
        console.error('Error syncing GitHub data:', err.response?.data || err.message);
        throw err;
    }
};
